package test;

import java.io.*;
import bandit.*;

public class SampleData {
/*
	public void generateSampleDataBernoulli() {
		ArmBernoulli arm1 = new ArmBernoulli("Arm1");
		ArmBernoulli arm2 = new ArmBernoulli("Arm2");
		ArmBernoulli arm3 = new ArmBernoulli("Arm3");
		
		try {
			FileWriter fw = new FileWriter("SampleDataBernoulli.dat");
			
			for (int n=0; n<60000; n++) {
				if (n%3==0) {
					int reward = (int)Math.round(arm1.drawReward(0.135));
					fw.write("Arm1\t" + reward + "\n");
				} else if (n%3==1) {
					int reward = (int)Math.round(arm2.drawReward(0.155));
					fw.write("Arm2\t" + reward + "\n");
				} else {
					int reward = (int)Math.round(arm3.drawReward(0.16));
					fw.write("Arm3\t" + reward + "\n");
				}
			}
			
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public void generateSampleDataGaussian() {
		ArmGaussian arm1 = new ArmGaussian("Arm1");
		ArmGaussian arm2 = new ArmGaussian("Arm2");
		ArmGaussian arm3 = new ArmGaussian("Arm3");
		
		try {
			FileWriter fw = new FileWriter("SampleDataGaussian.dat");
			
			for (int n=0; n<60000; n++) {
				if (n%3==0) {
					double reward = arm1.drawReward(2.0, 50);
					fw.write("Arm1\t" + reward + "\n");
				} else if (n%3==1) {
					double reward = arm2.drawReward(5.0, 60);
					fw.write("Arm2\t" + reward + "\n");
				} else {
					double reward = arm3.drawReward(6, 30);
					fw.write("Arm3\t" + reward + "\n");
				}
			}
			
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public void generateSampleDataBernoulliContextual() {
		ArmBernoulli arm11 = new ArmBernoulli("Arm1");
		ArmBernoulli arm12 = new ArmBernoulli("Arm2");
		ArmBernoulli arm13 = new ArmBernoulli("Arm3");
		ArmBernoulli arm21 = new ArmBernoulli("Arm1");
		ArmBernoulli arm22 = new ArmBernoulli("Arm2");
		ArmBernoulli arm23 = new ArmBernoulli("Arm3");
		
		try {
			FileWriter fw = new FileWriter("SampleDataBernoulliContextual.dat");
			
			for (int n=0; n<60000; n++) {
				int m=n%6;
				int reward;
				switch (m) {
				case 0:
					reward = (int)Math.round(arm11.drawReward(0.135));
					fw.write("1\tArm1\t" + reward + "\n");
					break;
				case 1:
					reward = (int)Math.round(arm12.drawReward(0.155));
					fw.write("1\tArm2\t" + reward + "\n");
					break;
				case 2:
					reward = (int)Math.round(arm13.drawReward(0.16));
					fw.write("1\tArm3\t" + reward + "\n");
					break;
				case 3:
					reward = (int)Math.round(arm21.drawReward(0.31));
					fw.write("2\tArm1\t" + reward + "\n");
					break;
				case 4:
					reward = (int)Math.round(arm22.drawReward(0.33));
					fw.write("2\tArm2\t" + reward + "\n");
					break;
				case 5:
					reward = (int)Math.round(arm23.drawReward(0.32));
					fw.write("2\tArm3\t" + reward + "\n");
					break;
				}
			}
			
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public void generateSampleDataGaussianContextual() {
		ArmGaussian arm11 = new ArmGaussian("Arm1");
		ArmGaussian arm12 = new ArmGaussian("Arm2");
		ArmGaussian arm13 = new ArmGaussian("Arm3");
		ArmGaussian arm21 = new ArmGaussian("Arm1");
		ArmGaussian arm22 = new ArmGaussian("Arm2");
		ArmGaussian arm23 = new ArmGaussian("Arm3");
		
		try {
			FileWriter fw = new FileWriter("SampleDataGaussianContextual.dat");
			
			for (int n=0; n<60000; n++) {
				int m=n%6;
				double reward;
				switch (m) {
				case 0:
					reward = arm11.drawReward(2.0, 50);
					fw.write("1\tArm1\t" + reward + "\n");
					break;
				case 1:
					reward = arm12.drawReward(5.0, 60);
					fw.write("1\tArm2\t" + reward + "\n");
					break;
				case 2:
					reward = arm13.drawReward(6.0, 30);
					fw.write("1\tArm3\t" + reward + "\n");
					break;
				case 3:
					reward = arm21.drawReward(20.0, 600);
					fw.write("2\tArm1\t" + reward + "\n");
					break;
				case 4:
					reward = arm22.drawReward(30.0, 1000);
					fw.write("2\tArm2\t" + reward + "\n");
					break;
				case 5:
					reward = arm23.drawReward(26.0, 800);
					fw.write("2\tArm3\t" + reward + "\n");
					break;
				}
			}
			
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	*/
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SampleData sd = new SampleData();
		//sd.generateSampleDataBernoulli();
		//sd.generateSampleDataGaussian();
//		sd.generateSampleDataBernoulliContextual();
		//sd.generateSampleDataGaussianContextual();
	}

}
