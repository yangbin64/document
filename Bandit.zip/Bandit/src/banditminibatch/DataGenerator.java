package banditminibatch;

import org.apache.commons.math3.distribution.BinomialDistribution;

public class DataGenerator {

	int armCount;
	double[] rates;
	
	public DataGenerator(double[] rates) {
		armCount = rates.length;
		this.rates = new double[armCount];
		
		for (int i=0; i<armCount; i++) {
			this.rates[i] = rates[i];
		}
	}
	
	public int[] generate(int[] traffics) {
		int[] rewards = new int[armCount];
		for (int i=0; i<armCount; i++) {
			double rate = rates[i];
			int traffic = traffics[i];
			
			BinomialDistribution bin = new BinomialDistribution(traffic, rate);
			rewards[i] = bin.sample();
		}
		
		return rewards;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
