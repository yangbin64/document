package banditminibatch;

import bandit.*;

import java.util.*;
import java.io.*;

import org.apache.commons.math3.distribution.*;

public class BanditMiniBatch {
	
	int TRAFFIC;
	
	double[] rates = {0.1, 0.12};
	DataGenerator datagen = new DataGenerator(rates);
	
	Model model = new Model("Bernoulli", 1, 2);
	
	public BanditMiniBatch(double rate1, double rate2, int traffic) {
		this.rates[0] = rate1;
		this.rates[1] = rate2;
		this.TRAFFIC = traffic;
	}
	
	public void simulate(String filename) {
		System.out.print("[" + this.rates[0] + "," + this.rates[1] + "] ");
		int round = 100000/TRAFFIC;
		
		model.constructArm("1", "1");
		model.constructArm("1", "2");
		
		try {
			FileWriter fw = new FileWriter(filename);
			
			System.out.print("" + TRAFFIC + ": ");
			
			int r=0;
			for (; r<round; r++) {
				if (r*TRAFFIC % 1000 == 0) {
					fw.write("" + r + ",");
					fw.write("" + TRAFFIC + ",");
					fw.write("" + model.armList.get("1").get("1").sum + ",");
					fw.write("" + model.armList.get("1").get("1").count + ",");
					fw.write("" + model.armList.get("1").get("2").sum + ",");
					fw.write("" + model.armList.get("1").get("2").count + ",");
					double sum = model.armList.get("1").get("1").sum + model.armList.get("1").get("2").sum;
					int count = model.armList.get("1").get("1").count + model.armList.get("1").get("2").count;
					fw.write("" + sum + ",");
					fw.write("" + count + ",");
					fw.write("" + (sum/count) + "\n");
					System.out.print(".");
				}
				
				int[] traffics = new int[2];
				HashMap<String, Double> ratioList = model.getRatios("1");
				
				double ratio0 = ratioList.get("1");
				double ratio1 = 1.0 - ratio0;
				if (TRAFFIC==1) {
					BinomialDistribution bin = new BinomialDistribution(1, ratio0);
					traffics[0] = bin.sample();
					traffics[1] = TRAFFIC-traffics[0];
				} else {
					traffics[0] = (int)(ratio0*TRAFFIC);
					traffics[1] = (int)(ratio1*TRAFFIC);
					int remaining = TRAFFIC - traffics[0] - traffics[1];
					if (remaining>0) {
						if (remaining>1) {
							System.out.println("Problem!");
						}
						double pr0 = ratio0*TRAFFIC - traffics[0];
						double pr1 = ratio1*TRAFFIC - traffics[1];
						BinomialDistribution bin = new BinomialDistribution(1, pr0/(pr0+pr1));
						int d = bin.sample();
						traffics[0] += d;
						traffics[1] += (1-d);
					}
				}
				
				int[] rewards = datagen.generate(traffics);
				
				model.armList.get("1").get("1").sum += rewards[0];
				model.armList.get("1").get("1").count += traffics[0];
				model.armList.get("1").get("2").sum += rewards[1];
				model.armList.get("1").get("2").count += traffics[1];
			}
			
			fw.write("" + r + ",");
			fw.write("" + TRAFFIC + ",");
			fw.write("" + model.armList.get("1").get("1").sum + ",");
			fw.write("" + model.armList.get("1").get("1").count + ",");
			fw.write("" + model.armList.get("1").get("2").sum + ",");
			fw.write("" + model.armList.get("1").get("2").count + ",");
			double sum = model.armList.get("1").get("1").sum + model.armList.get("1").get("2").sum;
			int count = model.armList.get("1").get("1").count + model.armList.get("1").get("2").count;
			fw.write("" + sum + ",");
			fw.write("" + count + ",");
			fw.write("" + (sum/count) + "\n");
			System.out.println("Finish!");
			
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int[] ts = {1,2,5,10,20,50,100,200,500,1000};
		
		if (args.length<3) return;
		
		for (int i=0; i<1000; i++) {
			double rate1 = Double.valueOf(args[0]);
			double rate2 = Double.valueOf(args[1]);
			for (int j=2; j<args.length; j++) {
				int t = Integer.valueOf(args[j]);
				String filename = "log_" + t + "_" + i + ".csv";
				BanditMiniBatch bmb = new BanditMiniBatch(rate1, rate2, t);
				bmb.simulate(filename);
			}
		}
	}

}
