package bandit;

import java.io.*;
import java.util.*;

public class BanditContextualBatch {

	final int STEP = 200;
	
	// add parameters to interface (modified by Yang 2015/10/08)
	public void updateModel(
			String armType,
			String filenamei,
			String filenamem,
			String filenamen,
			double sum_prior,
			int count_prior) {
		
		// add parameters to interface (modified by Yang 2015/10/08)
		Model model = new Model(armType, sum_prior, count_prior);
		
		File file = new File(filenamem);
		if (file.exists()) {
			// add parameters to interface (modified by Yang 2015/10/08)
			model.importJson(filenamem, sum_prior, count_prior);
		}
		
		try {
			FileReader fr = new FileReader(filenamei);
			BufferedReader buf = new BufferedReader(fr);
			String s;
			
			while ((s=buf.readLine())!=null) {
				String[] ss = s.split("\t");
				
				String contextid = ss[0];
				String armName = ss[1];
				double reward = Double.valueOf(ss[2]);
				
				model.update(contextid, armName, reward);
			}
			
			fr.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		
		model.exportJson(filenamen);
	}
	
	// add parameters to interface (modified by Yang 2015/10/08)
	public HashMap<String, HashMap<String, Double>> outputRatios(
			String armType,
			String filenamem,
			double sum_prior,
			int count_prior) {
		
		// add parameters to interface (modified by Yang 2015/10/08)
		Model model = new Model(armType, sum_prior, count_prior);
		
		File file = new File(filenamem);
		if (file.exists()) {
			// add parameters to interface (modified by Yang 2015/10/08)
			model.importJson(filenamem, sum_prior, count_prior);
		}
		
		HashMap<String, HashMap<String, Double>> ratios = new HashMap<String, HashMap<String, Double>>();
		
		for (Iterator<Map.Entry<String, HashMap<String, Arm>>> it=model.armList.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, HashMap<String, Arm>> entry = it.next();
			String armName = entry.getKey();
			ratios.put(armName, model.getRatios(armName));
		}
		
		return ratios;
	}
	
	// add parameters to interface (modified by Yang 2015/10/08)
	public HashMap<String, HashMap<String, Double>> OutputRatiosWithNewArms(
			String armType,
			String filenamem,
			double percentage,
			String[] newArmNames,
			double sum_prior,
			int count_prior) {
		
		// add parameters to interface (modified by Yang 2015/10/08)
		HashMap<String, HashMap<String, Double>> ratios = outputRatios(armType, filenamem, sum_prior, count_prior);
		
		for (Iterator<Map.Entry<String, HashMap<String, Double>>> it=ratios.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, HashMap<String, Double>> entry = it.next();
			//String contextid = entry.getKey();
			HashMap<String, Double> ratio = entry.getValue();
			
			double per = percentage;
			if (ratio.isEmpty()) {
				per = 1;
			}
			
			for (Iterator<Map.Entry<String, Double>> it2=ratio.entrySet().iterator(); it2.hasNext(); ) {
				Map.Entry<String, Double> entry2 = it2.next();
				String name = entry2.getKey();
				double value = entry2.getValue();
				ratio.put(name, value*(1-per));
			}
			
			for (int i=0; i<newArmNames.length; i++) {
				if (!ratio.containsKey(newArmNames[i])) {
					ratio.put(newArmNames[i], per/newArmNames.length);
				} else {
					System.out.println("Arm " + newArmNames[i] + " exists!");
					return null;
				}
			}
		}
		
		return ratios;
	}
	
	public void removeArms(
			String armType,
			String filenamem,
			String filenamen,
			String[] armNames) {
		
		// add parameters to interface (modified by Yang 2015/10/08)
		Model model = new Model(armType, 1, 1);
		
		File file = new File(filenamem);
		if (file.exists()) {
			// add parameters to interface (modified by Yang 2015/10/08)
			model.importJson(filenamem, -1, -1);
		}
		
		model.removeArms(armNames);
		
		model.exportJson(filenamen);
	}
	
	public void testGaussianContextual() {
		updateModel("Gaussian", "SampleDataGaussianContextual.dat", "nn", "model1GC.json", 1, 1);
		updateModel("Gaussian", "SampleDataGaussianContextual.dat", "model1GC.json", "model2GC.json", 1, 1);
		updateModel("Gaussian", "SampleDataGaussianContextual.dat", "model2GC.json", "model3GC.json", 1, 1);
		System.out.println(outputRatios("Gaussian", "model1GC.json", 1, 1));
		System.out.println(outputRatios("Gaussian", "model2GC.json", 1, 1));
		System.out.println(outputRatios("Gaussian", "model3GC.json", 1, 1));
	}
	
	public void testBernoulliContextual() {
		updateModel("Bernoulli", "SampleDataBernoulliContextual.dat", "nn", "model1BC.json", 1, 1);
		updateModel("Bernoulli", "SampleDataBernoulliContextual.dat", "model1BC.json", "model2BC.json", 1, 1);
		updateModel("Bernoulli", "SampleDataBernoulliContextual.dat", "model2BC.json", "model3BC.json", 1, 1);
		System.out.println(outputRatios("Bernoulli", "model1BC.json", 1, 1));
		System.out.println(outputRatios("Bernoulli", "model2BC.json", 1, 1));
		System.out.println(outputRatios("Bernoulli", "model3BC.json", 1, 1));
	}
	
	public void testBernoulliAddArms() {
		String[] newArmNames = {"new1", "new2"};
		System.out.println(OutputRatiosWithNewArms("Bernoulli", "model1BC.json", 0.2, newArmNames, 1, 1));
		System.out.println(OutputRatiosWithNewArms("Bernoulli", "model2BC.json", 0.2, newArmNames, 1, 1));
		System.out.println(OutputRatiosWithNewArms("Bernoulli", "model3BC.json", 0.2, newArmNames, 1, 1));
	}
	
	public void testBernoulliRemoveArms() {
		String[] newArmNames = {"Arm1", "Arm3"};
		removeArms("Bernoulli", "model1BC.json", "model1BCrm.json", newArmNames);
		
		System.out.println(OutputRatiosWithNewArms("Bernoulli", "model1BCrm.json", 0.2, newArmNames, 1, 1));
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BanditContextualBatch bb = new BanditContextualBatch();
		//bb.testBernoulliContextual();
		//bb.testBernoulliAddArms();
		bb.testBernoulliRemoveArms();
		
		//bb.testGaussianContextual();
	}

}
