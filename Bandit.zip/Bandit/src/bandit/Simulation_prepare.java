package bandit;

/*
 * generate a history data based on impression and action data
 */

import java.io.*;

public class Simulation_prepare {
	String filenamew = "";
	int[] IMP = {};
	int[] CT = {};
	
	void parse(String[] args) {
		filenamew = args[0];
		String[] imps = args[1].split(",");
		String[] cts = args[2].split(",");
		
		IMP = new int[imps.length];
		CT = new int[imps.length];
		for (int a=0; a<imps.length; a++) {
			IMP[a] = Integer.valueOf(imps[a]);
			CT[a] = Integer.valueOf(cts[a]);
		}
	}
	
	void generate() {
		try {
			FileWriter fw = new FileWriter(filenamew);
			
			for (int a=0; a<IMP.length; a++) {
				String Arm = "Arm" + a;
				for (int i=0; i<IMP[a]; i++) {
					int Reward = 0;
					if(i<CT[a]) {
						Reward = 1;
					}
					fw.write(Arm + "\t" + Reward + "\n");
				}
			}
			
			fw.close();
		} catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Simulation_prepare sp = new Simulation_prepare();
		sp.parse(args);
		sp.generate();
	}

}
