package bandit;

import java.util.*;
import org.apache.commons.math3.distribution.*;
//import com.google.gson.internal.*;

public class Model {
	final int STEP = 200;
	
	String armType = "";
	double sum_prior;
	int count_prior;
	
	// Context id -> Arm name -> Arm
	public HashMap<String, HashMap<String, Arm>> armList = new HashMap<String, HashMap<String, Arm>>();
	
	// add parameters to interface (modified by Yang 2015/10/08)
	public Model(String armType, double sum_prior, int count_prior) {
		this.armType = armType;
		// add parameters to interface (added by Yang 2015/10/08)
		this.sum_prior = sum_prior;
		this.count_prior = count_prior;
	}
	
	public void constructArm(String contenxtid, String armName) {
		if (!armList.containsKey(contenxtid)) {
			armList.put(contenxtid, new HashMap<String, Arm>());
		}
		
		if (!armList.get(contenxtid).containsKey(armName)) {
			if (armType.equalsIgnoreCase("Bernoulli")) {
				// add parameters to interface (modified by Yang 2015/10/08)
				armList.get(contenxtid).put(armName, new ArmBernoulli(armName, sum_prior, count_prior));
			} else {
				// add parameters to interface (modified by Yang 2015/10/08)
				armList.get(contenxtid).put(armName, new ArmGaussian(armName, sum_prior, count_prior));
			}
		}
	}
	/*
	public void constructArm(String contenxtid, LinkedTreeMap<String, Object> map) {
		if (!armList.containsKey(contenxtid)) {
			armList.put(contenxtid, new HashMap<String, Arm>());
		}
		
		String name = (String)map.get("name");
		if (!armList.get(contenxtid).containsKey(name)) {
			if (armType.equalsIgnoreCase("Bernoulli")) {
				armList.get(contenxtid).put(name, new ArmBernoulli(map));
			} else {
				armList.get(contenxtid).put(name, new ArmGaussian(map));
			}
		}
	}
	
	public void constructArm(String contextid, ArmParameters armParameters) {
		if (!armList.containsKey(contextid)) {
			armList.put(contextid, new HashMap<String, Arm>());
		}
		
		String name = armParameters.armName;
		if (!armList.get(contextid).containsKey(name)) {
			if (armType.equalsIgnoreCase("Bernoulli")) {
				armList.get(contextid).put(name, new ArmBernoulli(armParameters));
			} else {
				armList.get(contextid).put(name, new ArmGaussian(armParameters));
			}
		}
	}
	*/
	public void update(String contextid, String armName, double reward) {
		constructArm(contextid, armName);
		
		armList.get(contextid).get(armName).update(reward);
	}
	
	public String select(String contextid) {
		String selectedArm = null;
		double bestReward = 0;
		
		if (!armList.containsKey(contextid))
			return null;
		
		for (Iterator<Map.Entry<String, Arm>> it=armList.get(contextid).entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, Arm> entry = it.next();
			String arm = entry.getKey();
			Arm g = entry.getValue();
			double reward = g.sample();
			if (selectedArm==null || reward>bestReward) {
				selectedArm = arm;
				bestReward = reward;
			}
		}
		
		return selectedArm;
	}
	
	public void output(String contextid) {
		if (!armList.containsKey(contextid))
			return;
		
		System.out.println("[Simulation result (bandit alrogithm)]");
		System.out.println("Arm\tReward\tSum\tCount");
		System.out.println("==============================");
		
		double sum = 0;
		int count = 0;
		for (Iterator<Map.Entry<String, Arm>> it=armList.get(contextid).entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, Arm> entry = it.next();
			Arm arm = entry.getValue();
			arm.output();
			sum += arm.getSum();
			count += arm.getCount();
		}
		
		double avg = sum/count;
		avg = ((double)Math.round(avg*1000))/1000;
		System.out.println("------------------------------");
		System.out.println("Summary\t" + avg + "\t" + sum + "\t" + count);
	}
	
	public HashMap<String, Double> getRatios(String contextid) {
		if (!armList.containsKey(contextid))
			return null;
		
		HashMap<String, Double> ratios = new HashMap<String, Double>();
		
		HashMap<String, AbstractRealDistribution> distributions = new HashMap<String, AbstractRealDistribution>();
		
		for (Iterator<Map.Entry<String, Arm>> it=armList.get(contextid).entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, Arm> entry = it.next();
			String name = entry.getKey();
			Arm arm = entry.getValue();
			
			distributions.put(name, arm.getDistribution());
		}
		
		for (Iterator<Map.Entry<String, AbstractRealDistribution>> it=distributions.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, AbstractRealDistribution> entry = it.next();
			String name = entry.getKey();
			AbstractRealDistribution distribution = entry.getValue();
			
			double ratio = 0;
			for (int x=0; x<STEP; x++) {
				double c = ((double)x+0.5)/STEP;
				double m = distribution.inverseCumulativeProbability(c);
				
				double p = 1.0/STEP;
				for (Iterator<Map.Entry<String, AbstractRealDistribution>> it2=distributions.entrySet().iterator(); it2.hasNext(); ) {
					Map.Entry<String, AbstractRealDistribution> entry2 = it2.next();
					String name2 = entry2.getKey();
					AbstractRealDistribution beta2 = entry2.getValue();
					
					if (!name2.equalsIgnoreCase(name)) {
						double c2 = beta2.cumulativeProbability(m);
						p *= c2;
					}
				}
				ratio += p;
			}
			
			ratios.put(name, ratio);
			
		}
		
		return ratios;
	}
	
	// add parameters to interface (modified by Yang 2015/10/08)
	public void importJson(String filenameJsonModel, double sum_prior, int count_prior) {
		ParameterList apl = new ParameterList();
		
		armList = apl.importJson(armType, filenameJsonModel);
		
		// add parameters to interface (added by Yang 2015/10/08)
		if (count_prior>0) {
			for (Iterator<Map.Entry<String, HashMap<String, Arm>>> it=armList.entrySet().iterator(); it.hasNext(); ) {
				Map.Entry<String, HashMap<String, Arm>> entry = it.next();
				HashMap<String, Arm> arms = entry.getValue();
				
				for (Iterator<Map.Entry<String, Arm>> it2= arms.entrySet().iterator(); it2.hasNext(); ) {
					Map.Entry<String, Arm> entry2 = it2.next();
					Arm arm = entry2.getValue();
					arm.sum_prior = sum_prior;
					arm.count_prior = count_prior;
				}
			}
		}
	}
	
	public void exportJson(String filenameJsonModel) {
		ParameterList apl = new ParameterList();
		
		apl.exportJson(armType, armList, filenameJsonModel);
	}
	
	public void removeArms(String[] armNames) {
		for (Iterator<Map.Entry<String, HashMap<String, Arm>>> it=armList.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, HashMap<String, Arm>> entry = it.next();
			HashMap<String, Arm> arms = entry.getValue();
			
			for (int i=0; i<armNames.length; i++) {
				if (arms.containsKey(armNames[i])) {
					arms.remove(armNames[i]);
				} else {
					System.out.println("Arm " + armNames[i] + " does not exist!");
				}
			}
		}
	}
	
	/*
	public void importJson(String filenameJsonModel) {
		try {
			InputStreamReader isr = new InputStreamReader(new FileInputStream(filenameJsonModel));
			JsonReader jsr = new JsonReader(isr);
			Gson gson = new Gson();
			HashMap<String, Map<String, LinkedTreeMap<String, Object>>> arms = gson.fromJson(jsr, HashMap.class);
			copyToArmList(arms);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public void exportJson(String filenameJsonModel) {
		File file = new File(filenameJsonModel);
		try (JsonWriter writer = new JsonWriter(new FileWriter(file))) {
			writer.setIndent(" ");
			Gson gson = new Gson();
			gson.toJson(armList, HashMap.class, writer);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public void copyToArmList(HashMap<String, Map<String, LinkedTreeMap<String, Object>>> armParameters) {
		for (Iterator<Map.Entry<String, Map<String, LinkedTreeMap<String, Object>>>> it=armParameters.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, Map<String, LinkedTreeMap<String, Object>>> entry = it.next();
			String contextid = entry.getKey();
			Map<String, LinkedTreeMap<String, Object>> armParameter = entry.getValue();
			
			for (Iterator<Map.Entry<String, LinkedTreeMap<String, Object>>> it2=armParameter.entrySet().iterator(); it2.hasNext(); ) {
				Map.Entry<String, LinkedTreeMap<String, Object>> entry2 = it2.next();
				LinkedTreeMap<String, Object> map = entry2.getValue();
				constructArm(contextid, map);
			}
		}
	}
	*/
}
