package bandit;

import org.apache.commons.math3.distribution.*;

public class ArmGaussian extends Arm {
	
	// add parameters to interface (modified by Yang 2015/10/08)
	public ArmGaussian(String name, double sum_prior, int count_prior) {
		super(name, sum_prior, count_prior);
	}
	
	public ArmGaussian(ParameterArm armParameter) {
		super(armParameter);
	}
	
	public ArmGaussian(String name, double sum, int count, double sum2) {
		super(name, sum, count, sum2);
	}
	
	public AbstractRealDistribution getDistribution() {
		double average = 1;
		double variance = 100;
		if (count>1) {
			average = sum/count;
			variance = Math.sqrt((sum2-average*average*count+0.01)/(count-1)/count);
		}
		// unbiased estimate of population variance: delta^2 = (x_i^2-x^2)/(n-1)
		// central limit theorem: delta^2/n
		
		return new NormalDistribution(average, variance);
	}
	
	public void update(double reward) {
		sum += reward;
		count++;
		sum2 += (reward*reward);
	}
	
	public double drawReward(double avg, double var) {
		NormalDistribution nd = new NormalDistribution(avg, var);
		return nd.sample();
	}
}
