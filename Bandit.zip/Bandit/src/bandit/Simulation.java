package bandit;

import java.io.*;
import java.util.*;
import org.apache.commons.math3.distribution.*;

public class Simulation {
	
	String armType = "";
	
	public class Simulator {
		public HashMap<String, ArrayList<Double>> armList = new HashMap<String, ArrayList<Double>>();
		
		public void addReward(String armName, double reward) {
			if (!armList.containsKey(armName)) {
				armList.put(armName, new ArrayList<Double>());
			}
			
			armList.get(armName).add(reward);
		}
		
		public double drawReward(String armName) {
			int size = armList.get(armName).size();
			int idx = (int)(Math.random()*size);
			return armList.get(armName).get(idx);
		}
		
		public void output() {
			System.out.println("[Original result]");
			System.out.println("Arm\tReward\tSum\tCount");
			System.out.println("==============================");
			
			double sum=0;
			int count=0;
			for (Iterator<Map.Entry<String, ArrayList<Double>>> it=armList.entrySet().iterator(); it.hasNext(); ) {
				Map.Entry<String, ArrayList<Double>> entry = it.next();
				String armName = entry.getKey();
				ArrayList<Double> rewardList = entry.getValue();
				double rewardSum = 0;
				int rewardCount = rewardList.size();
				for (Iterator<Double> it2=rewardList.iterator(); it2.hasNext(); ) {
					double reward = it2.next();
					rewardSum += reward;
				}
				sum += rewardSum;
				count += rewardCount;
				double average = rewardSum/rewardCount;
				double rewardAvg_Per = ((double)Math.round(average*100000))/1000;
				System.out.println(armName + "\t" + String.format("%1$.3f",rewardAvg_Per) + "%" + "\t" + rewardSum + "\t" + rewardCount);
			}
			
			double avg = sum/count;
			avg = ((double)Math.round(avg*1000))/1000;
			System.out.println("------------------------------");
			System.out.println("Summary\t" + avg + "\t" + sum + "\t" + count);
			
			System.out.println();
		}
	}
	
	// add parameters to interface (modified by Yang 2015/10/08)
	public Simulation(String armtype, double sum_prior, int count_prior) {
		this.armType = armtype;
		// add parameters to interface (modified by Yang 2015/10/08)
		model = new Model(armType, sum_prior, count_prior);
	}
	
	Simulator simulator = new Simulator();
	
	public void modeling(String filename) {
		System.out.println("=== Summarizing data begin ===");
		System.out.println("Input file: " + filename);
		
		int count = 0;
		try {
			FileReader fr = new FileReader(filename);
			BufferedReader buf = new BufferedReader(fr);
			String s;
			
			while ((s=buf.readLine())!=null) {
				count++;
				String[] ss=s.split("\t");
				
				String armName = ss[0];
				double reward = Double.valueOf(ss[1]);
				
				simulator.addReward(armName, reward);
			}
			
			fr.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		
		System.out.println("Data size: " + count);
		System.out.println("=== Summarizing data end ===");
	}
	
	Model model;
	/*
	public Arm constructArm(String armName) {
		Arm arm;
		
		if (armType.equalsIgnoreCase("Bernoulli")) {
			arm = new ArmBernoulli(armName);
		} else {
			arm = new ArmGaussian(armName);
		}
		
		return arm;
	}
	*/
	public void simulate(String filename, String filenamew) {
		System.out.println("=== Simulation begin ===");
		System.out.println("Arm type: " + armType);
		System.out.println("Input file: " + filename);
		System.out.println("Output file: " + filenamew);
		
		for (Iterator<Map.Entry<String, ArrayList<Double>>> it=simulator.armList.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, ArrayList<Double>> entry = it.next();
			String armName = entry.getKey();
			
			model.constructArm("-", armName);
		}
		
		try {
			FileReader fr = new FileReader(filename);
			BufferedReader buf = new BufferedReader(fr);
			
			FileWriter fw = new FileWriter(filenamew);
			
			while ((buf.readLine())!=null) {
				String armName = model.select("-");
				
				double reward = simulator.drawReward(armName);
				
//				Arm arm = null;
//				if (!model.exists(armName))
//					arm = constructArm(armName);
				model.update("-", armName, reward);
				
				if (armType.equalsIgnoreCase("Bernoulli")) {
					fw.write(armName + "\t" + (int)Math.round(reward) + "\n");
				} else if (armType.equalsIgnoreCase("Gaussian")) {
					fw.write(armName + "\t" + reward + "\n");
				}
			}
			
			fw.close();
			fr.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		
		System.out.println("=== Simulation end ===");
	}
	
	public void simulate_minibatch(String filename, String filenamew, int block) {
		System.out.println("=== Simulation begin ===");
		System.out.println("Arm type: " + armType);
		System.out.println("Input file: " + filename);
		System.out.println("Output file: " + filenamew);
		
		for (Iterator<Map.Entry<String, ArrayList<Double>>> it=simulator.armList.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, ArrayList<Double>> entry = it.next();
			String armName = entry.getKey();
			
			model.constructArm("-", armName);
		}
		
		try {
			FileReader fr = new FileReader(filename);
			BufferedReader buf = new BufferedReader(fr);
			
			FileWriter fw = new FileWriter(filenamew);
			
			HashMap<String, Double> sampleratios = new HashMap<String, Double>();
			EnumeratedIntegerDistribution eid = null;
			String[] arms = {};
			
			long count = 0;
			while ((buf.readLine())!=null) {
				if (count%block==0) {
					System.out.println();
					System.out.print("Compute ratios (block " + (int)(count/block) + ")");
					
					sampleratios = model.getRatios("-");
					
					int size = sampleratios.size();
					int[] singletons = new int[size];
					double[] probabilities = new double[size];
					arms = new String[size];
					
					int s=0;
					for (Iterator<Map.Entry<String, Double>> it=sampleratios.entrySet().iterator(); it.hasNext(); ) {
						Map.Entry<String, Double> entry = it.next();
						String arm = entry.getKey();
						double probability = entry.getValue();
						singletons[s] = s;
						probabilities[s] = probability;
						arms[s] = arm;
						s++;
					}
					
					eid = new EnumeratedIntegerDistribution(singletons, probabilities);
					
					System.out.print(" | ");
				}
				
				count++;
				
				int a = eid.sample();
				String armName = arms[a];
				
				double reward = simulator.drawReward(armName);
				
//				Arm arm = null;
//				if (!model.exists(armName))
//					arm = constructArm(armName);
				model.update("-", armName, reward);
				
				if (armType.equalsIgnoreCase("Bernoulli")) {
					fw.write(armName + "\t" + (int)Math.round(reward) + "\n");
				} else if (armType.equalsIgnoreCase("Gaussian")) {
					fw.write(armName + "\t" + reward + "\n");
				}
			}
			
			fw.close();
			fr.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		
		System.out.println("=== Simulation end ===");
	}
	
	public void output() {
		simulator.output();
		model.output("-");
	}
	
	public static void help() {
		System.out.println();
		System.out.println("[Command]");
		System.out.println("  java -jar Simulation.jar <ArmType> <filename1> <filename2>");
		System.out.println("[Parameters]");
		System.out.println("  <ArmType> - 'Bernoulli' or 'Gaussian'");
		System.out.println("  <filename1> - The file name of input file");
		System.out.println("  <filename2> - The file name of output file");
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String filename = "SampleDataBernoulli.dat"; //args[0];
		//String filenamew = "SimulationBernoulli.dat"; //args[1];
		
		//String filename = "SampleDataGaussian.dat"; //args[0];
		//String filenamew = "SimulationGaussian.dat"; //args[1];
		
		if (args.length<3) {
			System.out.println("Parameter not enough!");
			help();
			return;
		}
		
		String armType = args[0];
		String filename = args[1];
		String filenamew = args[2];
		int block = -1;
		if (args.length>=4) {
			block = Integer.valueOf(args[3]);
		}
		
		if (!armType.equalsIgnoreCase("Bernoulli")&&!armType.equalsIgnoreCase("Gaussian")) {
			System.out.println("Parameter error!");
			help();
			return;
		}
		
		File file = new File(filename);
		if (!file.exists()) {
			System.out.println("Parameter " + filename + " not exist!");
			help();
			return;
		}
		
		// add parameters to interface (modified by Yang 2015/10/08)
		Simulation sim = new Simulation(armType, 1, 2);
		
		sim.modeling(filename);
		System.out.println();
		if (block>0) {
			sim.simulate_minibatch(filename, filenamew, block);
		} else {
			sim.simulate(filename, filenamew);
		}
		System.out.println();
		sim.output();
	}

}
