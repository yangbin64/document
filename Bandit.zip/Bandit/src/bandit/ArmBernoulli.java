package bandit;

import org.apache.commons.math3.distribution.*;

public class ArmBernoulli extends Arm {
	
	// add parameters to interface (modified by Yang 2015/10/08)
	public ArmBernoulli(String name, double sum_prior, int count_prior) {
		super(name, sum_prior, count_prior);
	}
	
	public ArmBernoulli(ParameterArm armParameter) {
		super(armParameter);
	}
	
	public ArmBernoulli(String name, double sum, int count, double sum2) {
		super(name, sum, count, sum2);
	}
	
	public AbstractRealDistribution getDistribution() {
		double count_p=sum;
		double count_n=count-sum;
		
		// add parameters to interface (added by Yang 2015/10/08)
		double count_p_prior = sum_prior;
		double count_n_prior = count_prior - sum_prior;
		
		// add parameters to interface (modified by Yang 2015/10/08)
		double alpha = count_p + count_p_prior;
		double beta = count_n + count_n_prior;
		
		return new BetaDistribution(alpha, beta);
	}
	
	public void update(double reward) {
		sum+=reward;
		count++;
	}
	
	public double drawReward(double prob) {
		BinomialDistribution bd = new BinomialDistribution(1, prob);
		return bd.sample();
	}
}
