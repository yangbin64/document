package bandit;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

public class Profile {
	
	public class ProfileJson {
		private String separator;
		private String projpath;
		
		// INPUTS
		private String datapath;
		private String datapathTransaction;
		private String filenameTransaction;
		
		// OUTPUTS
		private String jsonpath;
		private String jsonnameModel;
		
		// LOGS
		private String logspath;
		
		public void init() {
			separator = "\\";
			projpath = "C:\\bandit";
			
			// INPUTS
			datapath = "data";
			datapathTransaction = "transaction";
			
			filenameTransaction = "transaction.txt";
			
			// OUTPUTS
			jsonpath = "jsons";
			jsonnameModel = "model.json";
			
			// LOGS
			logspath = "logs";
		}
		
		public String getfilenameTransaction() {
			return projpath + separator + datapath + separator + datapathTransaction + separator + filenameTransaction;
		}
		
		public String getjsonnameModel() {
			return projpath + separator + jsonpath + separator + jsonnameModel;
		}
		
		public String getlogspath() {
			return projpath + separator + logspath + separator;
		}
	}
	
	public ProfileJson profileJson = new ProfileJson();
	
	public Profile() {
		try {
			importJson();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public void init() {
		profileJson.init();
	}
	
	public void importJson() throws IOException {
		try {
			InputStreamReader isr = new InputStreamReader(new FileInputStream("profile.json"));
			JsonReader jsr = new JsonReader(isr);
			Gson gson = new Gson();
			profileJson = gson.fromJson(jsr, ProfileJson.class);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public void exportJson() throws IOException {
		File file = new File("profile.json");
		try (JsonWriter writer = new JsonWriter(new FileWriter(file))) {
			writer.setIndent(" ");
			Gson gson = new Gson();
			gson.toJson(profileJson, ProfileJson.class, writer);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Profile profile = new Profile();
		try {
			profile.exportJson();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
