package bandit;

import org.apache.commons.math3.distribution.*;

public abstract class Arm {
	
	public String name;
	
	// add parameters to interface (added by Yang 2015/10/08)
	public double sum_prior;
	public int count_prior;
	
	public double sum;
	public int count;
	public double sum2;
	
	// add parameters to interface (modified by Yang 2015/10/08)
	public Arm(String name, double sum_prior, int count_prior) {
		this(name, 0, 0, 0);
		this.sum_prior = sum_prior;
		this.count_prior = count_prior;
	}
	
	public Arm(ParameterArm armParameter) {
		this.name=armParameter.name;
		this.sum=armParameter.sum;
		this.count=armParameter.count;
		this.sum2=armParameter.sum2;
	}
	
	public Arm(String name, double sum, int count, double sum2) {
		this.name=name;
		this.sum=sum;
		this.count=count;
		this.sum2=sum2;
		//distribution = new NormalDistribution(p_average, p_variance);
	}
	
	public abstract AbstractRealDistribution getDistribution();
	
	public abstract void update(double reward);
	
	public double sample() {
		AbstractRealDistribution distribution = getDistribution();
		double draw = distribution.sample();
		return draw;
	}
	
	public void output() {
		System.out.println(name + "\t" + getAvg() + "\t" + sum + "\t" + count);
	}
	
	public double getSum() {
		return sum;
	}
	
	public int getCount() {
		return count;
	}
	
	public double getAvg() {
		double avg = sum/count;
		avg = ((double)Math.round(avg*1000))/1000;
		return avg;
	}
}
