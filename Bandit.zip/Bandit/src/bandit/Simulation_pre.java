package bandit;

/*
 * generate a history data based on impression and action data
 */

import java.io.*;
import java.util.*;

public class Simulation_pre {
	int m = 2;
	int IMP[] = {744144, 744321};
	int CT[] = {390, 421};
	String filenamew = "E:\\bandit\\banditSimulator\\temp\\sampledata.dat";
	
	ArrayList<Integer> data;
	
	void generate() {
		try {
			FileWriter fw = new FileWriter(filenamew);
			
			int n = IMP[0]+IMP[1];
			int remainder_imp[] = new int[2];
			remainder_imp[0] = IMP[0];
			remainder_imp[1] = IMP[1];
			int remainder_ct[] = new int[2];
			remainder_ct[0] = CT[0];
			remainder_ct[1] = CT[1];
			
			for (int i=0; i<n; i++) {
				String Arm = "";
				int Reward = 0;
				
				if (remainder_imp[0]>0 && remainder_imp[1]>0) {
					if (i%2==0) {
						Arm = "Arm1";
					} else {
						Arm = "Arm2";
					}
				} else if (remainder_imp[0]>0) {
					Arm = "Arm1";
				} else {
					Arm = "Arm2";
				}
				
				if (Arm.equalsIgnoreCase("Arm1")) {
					remainder_imp[0]--;
					
					if (remainder_ct[0]>0) {
						Reward = 1;
						remainder_ct[0]--;
					}
				} else {
					remainder_imp[1]--;
					
					if (remainder_ct[1]>0) {
						Reward = 1;
						remainder_ct[1]--;
					}
				}
				
				fw.write(Arm + "\t" + Reward + "\n");
			}
			
			fw.close();
		} catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Simulation_pre sp = new Simulation_pre();
		sp.generate();
	}

}
