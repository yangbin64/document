package bandit;

import java.io.*;
import java.util.*;

public class Simulation_report {

	String filename = "E:\\bandit\\banditSimulator\\sweets_9682335_9682335\\sumilationresult.dat";
	String filenamew = "E:\\bandit\\banditSimulator\\sweets_9682335_9682335\\sumilationreport.dat";
	int step = 4430;
	
	public void report() {
		HashMap<String, Integer> sums = new HashMap<String, Integer>();
		HashMap<String, Integer> counts = new HashMap<String, Integer>();
		
		try {
			FileReader fr = new FileReader(filename);
			BufferedReader buf = new BufferedReader(fr);
			String s;
			
			FileWriter fw = new FileWriter(filenamew);
			
			int n=0;
			int g=0;
			while ((s=buf.readLine())!=null) {
				String[] ss = s.split("\t");
				
				String arm = ss[0];
				int reward = Integer.valueOf(ss[1]);
				
				if (!sums.containsKey(arm)) {
					sums.put(arm, 0);
					counts.put(arm, 0);
				}
				
				int sum = sums.get(arm);
				sums.put(arm, sum+reward);
				
				int count = counts.get(arm);
				counts.put(arm, count+1);
				
				n++;
				if (n>=step) {
					for (Iterator<Map.Entry<String, Integer>> it=sums.entrySet().iterator(); it.hasNext(); ) {
						Map.Entry<String, Integer> entry = it.next();
						String a = entry.getKey();
						int r = entry.getValue();
						int t = counts.get(a);
						fw.write("" + g + "\t" + a + "\t" + r + "\t" + t + "\n");
					}
					
					sums = new HashMap<String, Integer>();
					counts = new HashMap<String, Integer>();
					
					n=0;
					g++;
				}
			}
			
			fw.close();
			fr.close();
		} catch (IOException e) {
			System.out.println(e);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Simulation_report sr = new Simulation_report();
		sr.report();
	}

}
