package bandit;

import java.io.*;
import java.util.*;

public class BanditBatch {

	final int STEP = 200;
	
	// add parameters to interface (modified by Yang 2015/10/08)
	public void updateModel(
			String armType,
			String filenamei,
			String filenamem,
			String filenamen,
			double sum_prior,
			int count_prior) {
		
		// add parameters to interface (modified by Yang 2015/10/08)
		Model model = new Model(armType, sum_prior, count_prior);
		
		File file = new File(filenamem);
		if (file.exists()) {
			// add parameters to interface (modified by Yang 2015/10/08)
			model.importJson(filenamem, sum_prior, count_prior);
		}
		
		try {
			FileReader fr = new FileReader(filenamei);
			BufferedReader buf = new BufferedReader(fr);
			String s;
			
			while ((s=buf.readLine())!=null) {
				String[] ss = s.split("\t");
				
				String armName = ss[0];
				double reward = Double.valueOf(ss[1]);
				
				model.update("-", armName, reward);
			}
			
			fr.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		
		model.exportJson(filenamen);
	}
	
	// add parameters to interface (modified by Yang 2015/10/08)
	public HashMap<String, Double> outputRatios(
			String armType,
			String filenamem,
			double sum_prior,
			int count_prior) {
		
		// add parameters to interface (modified by Yang 2015/10/08)
		Model model = new Model(armType, sum_prior, count_prior);
		
		File file = new File(filenamem);
		if (file.exists()) {
			// add parameters to interface (modified by Yang 2015/10/08)
			model.importJson(filenamem, sum_prior, count_prior);
		}
		
		HashMap<String, Double> ratios = model.getRatios("-");
		
		return ratios;
	}
	
	// add parameters to interface (modified by Yang 2015/10/08)
	public HashMap<String, Double> OutputRatiosWithNewArms(
			String armType,
			String filenamem,
			double percentage,
			String[] newArmNames,
			double sum_prior,
			int count_prior) {
		
		// add parameters to interface (modified by Yang 2015/10/08)
		HashMap<String, Double> ratios = outputRatios(armType, filenamem, sum_prior, count_prior);
		
		double per = percentage;
		if (ratios.isEmpty()) {
			per = 1;
		}
		
		for (Iterator<Map.Entry<String, Double>> it2=ratios.entrySet().iterator(); it2.hasNext(); ) {
			Map.Entry<String, Double> entry2 = it2.next();
			String name = entry2.getKey();
			double value = entry2.getValue();
			ratios.put(name, value*(1-per));
		}
		
		for (int i=0; i<newArmNames.length; i++) {
			if (!ratios.containsKey(newArmNames[i])) {
				ratios.put(newArmNames[i], per/newArmNames.length);
			} else {
				System.out.println("Arm " + newArmNames[i] + " exists!");
				return null;
			}
		}
		
		return ratios;
	}
	
	public void removeArms(
			String armType,
			String filenamem,
			String filenamen,
			String[] armNames) {
		
		Model model = new Model(armType, 1, 1);
		
		File file = new File(filenamem);
		if (file.exists()) {
			// add parameters to interface (modified by Yang 2015/10/08)
			model.importJson(filenamem, -1, -1);
		}
		
		model.removeArms(armNames);
		
		model.exportJson(filenamen);
	}
	
	public void testGaussian() {
		updateModel("Gaussian", "SampleDataGaussian.dat", "nn", "model1.json", 1, 1);
		updateModel("Gaussian", "SampleDataGaussian.dat", "model1.json", "model2.json", 1, 1);
		updateModel("Gaussian", "SampleDataGaussian.dat", "model2.json", "model3.json", 1, 1);
		System.out.println(outputRatios("Gaussian", "model1.json", 1, 1));
		System.out.println(outputRatios("Gaussian", "model2.json", 1, 1));
		System.out.println(outputRatios("Gaussian", "model3.json", 1, 1));
	}
	
	public void testBernoulli() {
		updateModel("Bernoulli", "SampleDataBernoulli.dat", "nn", "model1.json", 1, 1);
		updateModel("Bernoulli", "SampleDataBernoulli.dat", "model1.json", "model2.json", 1, 1);
		updateModel("Bernoulli", "SampleDataBernoulli.dat", "model2.json", "model3.json", 1, 1);
		System.out.println(outputRatios("Bernoulli", "model1.json", 1, 1));
		System.out.println(outputRatios("Bernoulli", "model2.json", 1, 1));
		System.out.println(outputRatios("Bernoulli", "model3.json", 1, 1));
	}
	
	public void testBernoulliAddArms() {
		String[] newArmNames = {"new1", "new2"};
		System.out.println(OutputRatiosWithNewArms("Bernoulli", "model1.json", 0.2, newArmNames, 1, 1));
		System.out.println(OutputRatiosWithNewArms("Bernoulli", "model2.json", 0.2, newArmNames, 1, 1));
		System.out.println(OutputRatiosWithNewArms("Bernoulli", "model3.json", 0.2, newArmNames, 1, 1));
	}
	
	public void testBernoulliRemoveArms() {
		String[] newArmNames = {"Arm1", "Arm3"};
		removeArms("Bernoulli", "model1.json", "model1rm.json", newArmNames);
		
		System.out.println(OutputRatiosWithNewArms("Bernoulli", "model1rm.json", 0.2, newArmNames, 1, 1));
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BanditBatch bb = new BanditBatch();
		//bb.testBernoulli();
		//bb.testGaussian();
		//bb.testBernoulliAddArms();
		bb.testBernoulliRemoveArms();
	}

}
