package bandit;

import java.io.*;
import java.util.*;
import org.apache.commons.math3.distribution.*;
//import com.google.gson.internal.*;

public class ModelForWatanabe {
	final int STEP = 200;
	
	public TreeMap<String, NormalDistribution> arms = new TreeMap<String, NormalDistribution>();
	
	public void constructArm(String filename) {
		arms = new TreeMap<String, NormalDistribution>();
		try {
			FileReader fr = new FileReader(filename);
			BufferedReader br = new BufferedReader(fr);
			String s = br.readLine();
			
			while ((s=br.readLine())!=null) {
				String[] ss = s.split(",");
				String name = ss[0];
				double ave = Double.valueOf(ss[1]);
				double std = Double.valueOf(ss[2]);
				arms.put(name, new NormalDistribution(ave, std));
			}
			
			fr.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	TreeMap<String, Double> ratios;
	
	public void getRatios() {
		ratios = new TreeMap<String, Double>();
		
		TreeMap<String, AbstractRealDistribution> distributions = new TreeMap<String, AbstractRealDistribution>();
		
		for (Iterator<Map.Entry<String, NormalDistribution>> it=arms.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, NormalDistribution> entry = it.next();
			String name = entry.getKey();
			NormalDistribution arm = entry.getValue();
			
			distributions.put(name, arm);
		}
		
		for (Iterator<Map.Entry<String, AbstractRealDistribution>> it=distributions.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, AbstractRealDistribution> entry = it.next();
			String name = entry.getKey();
			AbstractRealDistribution distribution = entry.getValue();
			
			double ratio = 0;
			for (int x=0; x<STEP; x++) {
				double c = ((double)x+0.5)/STEP;
				double m = distribution.inverseCumulativeProbability(c);
				
				double p = 1.0/STEP;
				for (Iterator<Map.Entry<String, AbstractRealDistribution>> it2=distributions.entrySet().iterator(); it2.hasNext(); ) {
					Map.Entry<String, AbstractRealDistribution> entry2 = it2.next();
					String name2 = entry2.getKey();
					AbstractRealDistribution beta2 = entry2.getValue();
					
					if (!name2.equalsIgnoreCase(name)) {
						double c2 = beta2.cumulativeProbability(m);
						p *= c2;
					}
				}
				ratio += p;
			}
			
			ratios.put(name, ratio);
		}
	}
	
	public void outputRatios(String filenamew) {
		try {
			FileWriter fw = new FileWriter(filenamew);
			
			for (Iterator<Map.Entry<String, Double>> it=ratios.entrySet().iterator(); it.hasNext(); ) {
				Map.Entry<String, Double> entry = it.next();
				String name = entry.getKey();
				double ratio = entry.getValue();
				
				fw.write(name + "," + ratio + "\n");
			}
			
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public static void main(String[] args) {
		ModelForWatanabe m = new ModelForWatanabe();
		m.constructArm(args[0]);
		m.getRatios();
		m.outputRatios(args[1]);
	}
}
