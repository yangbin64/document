package bandit;

import java.io.*;
import java.util.*;

import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

class ParameterArm {
	public String name;
	public double sum;
	public int count;
	public double sum2;
	
	ParameterArm(Arm arm) {
		this.name = arm.name;
		this.sum = arm.sum;
		this.count = arm.count;
		this.sum2 = arm.sum2;
	}
}

class ParameterAll {
	String armType;
	public HashMap<String, HashMap<String, ParameterArm>> Parameters = new HashMap<String, HashMap<String, ParameterArm>>();
}

public class ParameterList {

	public ParameterAll parameterAll = new ParameterAll();
	
	public HashMap<String, HashMap<String, Arm>> importJson(String armType, String filenameJsonModel) {
		try {
			InputStreamReader isr = new InputStreamReader(new FileInputStream(filenameJsonModel));
			JsonReader jsr = new JsonReader(isr);
			Gson gson = new Gson();
			parameterAll = gson.fromJson(jsr, ParameterAll.class);
		} catch (Exception e) {
			System.out.println(e);
		}
		
		HashMap<String, HashMap<String, Arm>> armList = new HashMap<String, HashMap<String, Arm>>();
		
		for (Iterator<Map.Entry<String, HashMap<String, ParameterArm>>> it=parameterAll.Parameters.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, HashMap<String, ParameterArm>> entry = it.next();
			String contextid = entry.getKey();
			HashMap<String, ParameterArm> parameters = entry.getValue();
			
			armList.put(contextid, new HashMap<String, Arm>());
			
			for (Iterator<Map.Entry<String, ParameterArm>> it2=parameters.entrySet().iterator(); it2.hasNext(); ) {
				Map.Entry<String, ParameterArm> entry2 = it2.next();
				String armName = entry2.getKey();
				ParameterArm armParameter = entry2.getValue();
				
				if (armType.equalsIgnoreCase("Bernoulli")) {
					armList.get(contextid).put(armName, new ArmBernoulli(armParameter));
				} else {
					armList.get(contextid).put(armName, new ArmGaussian(armParameter));
				}
			}
		}
		return armList;
	}
	
	public void exportJson(String armType, HashMap<String, HashMap<String, Arm>> armList, String filenameJsonModel) {
		parameterAll.armType = armType;
		
		for (Iterator<Map.Entry<String, HashMap<String, Arm>>> it=armList.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, HashMap<String, Arm>> entry = it.next();
			String contextid = entry.getKey();
			HashMap<String, Arm> arms = entry.getValue();
			
			parameterAll.Parameters.put(contextid, new HashMap<String, ParameterArm>());
			
			for (Iterator<Map.Entry<String, Arm>> it2=arms.entrySet().iterator(); it2.hasNext(); ) {
				Map.Entry<String, Arm> entry2 = it2.next();
				String armName = entry2.getKey();
				Arm arm = entry2.getValue();
				
				parameterAll.Parameters.get(contextid).put(armName, new ParameterArm(arm));
			}
		}
		
		File file = new File(filenameJsonModel);
		try (JsonWriter writer = new JsonWriter(new FileWriter(file))) {
			writer.setIndent(" ");
			Gson gson = new Gson();
			gson.toJson(parameterAll, ParameterAll.class, writer);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
