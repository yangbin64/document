package bandit;

import java.io.File;
import java.util.HashMap;

public class Bandit {

	public static void help() {
		// add parameters to interface (modified by Yang 2015/10/08) >>>
		System.out.println();
		System.out.println("[Command]");
		System.out.println("  java -jar bandit.jar <Operation> <ArmType> <SubOptions>");
		System.out.println("[Parameters]");
		System.out.println("  <Operation> - 'Update' or 'Ratios' or 'RatiosNewArms' or 'RemoveArms'");
		System.out.println("  <ArmType> - 'Bernoulli' or 'Gaussian'");
		System.out.println("  <SubOption>:");
		System.out.println();
		System.out.println("    1. If <Operation> = 'Update'");
		System.out.println("      <SubOptions> = <prior1> <prior2> <filename1> <filename2> <filename3>");
		System.out.println("        <prior1> - The first prior");
		System.out.println("        <prior2> - The second prior");
		System.out.println("        <filename1> - The file name of input file (history data)");
		System.out.println("        <filename2> - The file name of current model file");
		System.out.println("        <filename3> - The file name of new model file");
		System.out.println("      e.g., java -jar bandit.jar Update 1 100 Bernoulli result1.tsv - model1.json");
		System.out.println("            java -jar bandit.jar Update 1 100 Bernoulli result2.tsv model1.json model2.json");
		System.out.println();
		System.out.println("    2. If <Operation> = 'Ratios'");
		System.out.println("      <SubOptions> = <prior1> <prior2> <filename3>");
		System.out.println("        <prior1> - The first prior");
		System.out.println("        <prior2> - The second prior");
		System.out.println("        <filename3> - The file name of model file");
		System.out.println("      e.g., java -jar bandit.jar Ratios 1 100 Bernoulli model2.json");
		System.out.println();
		System.out.println("    3. If <Operation> = 'RatiosNewArms'");
		System.out.println("      <SubOptions> = <prior1> <prior2> <filename2> <percentage> <arm name 1> <arm name 2> ...");
		System.out.println("        <prior1> - The first prior");
		System.out.println("        <prior2> - The second prior");
		System.out.println("        <filename2> - The file name of current model file");
		System.out.println("        <percentage> - A real number less than 1.0");
		System.out.println("        <arm name 1> <arm name 2> ... - Arms to be added");
		System.out.println("      e.g., java -jar bandit.jar RatiosNewArms Bernoulli model1.json 0.2 new1 new2");
		System.out.println();
		System.out.println("    4. If <Operation> = 'RemoveArms'");
		System.out.println("      <SubOptions> = <filename2> <filename3> <arm name 1> <arm name 2> ...");
		System.out.println("        <filename2> - The file name of current model file");
		System.out.println("        <filename3> - The file name of new model file");
		System.out.println("        <arm name 1> <arm name 2> ... - Arms to be removed");
		System.out.println("      e.g., java -jar bandit.jar RemoveArms Bernoulli model1.json model1.json new1 Arm2");
		// add parameters to interface (modified by Yang 2015/10/08) <<<
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		if (args.length<3) {
			System.out.println("[Error] Parameter not enough!");
			help();
			return;
		}
		
		String Operation = args[0];
		String armType = args[1];
		
		if (!Operation.equalsIgnoreCase("Update")
			&&!Operation.equalsIgnoreCase("Ratios")
			&&!Operation.equalsIgnoreCase("RatiosNewArms")
			&&!Operation.equalsIgnoreCase("RemoveArms")) {
			
			System.out.println("[Error] Parameter is invalid!");
			help();
			return;
		}
		
		if (!armType.equalsIgnoreCase("Bernoulli")&&!armType.equalsIgnoreCase("Gaussian")) {
			System.out.println("[Error] Parameter is invalid!");
			help();
			return;
		}
		
		if (Operation.equalsIgnoreCase("Update")) {
			// add parameters to interface (modified by Yang 2015/10/08)
			if (args.length<7) {
				System.out.println("[Error] Parameter not enough!");
				help();
				return;
			}
			
			// add parameters to interface (added by Yang 2015/10/08)
			double sum_prior = Double.valueOf(args[2]);
			int count_prior = Integer.valueOf(args[3]);
			// add parameters to interface (modified by Yang 2015/10/08)
			String filenamei = args[4];
			String filenamem = args[5];
			String filenamen = args[6];
			
			File file = new File(filenamei);
			if (!file.exists()) {
				System.out.println("[Error] File " + filenamei + " not exist!");
				help();
				return;
			}
			
			BanditContextualBatch bb = new BanditContextualBatch();
			// add parameters to interface (modified by Yang 2015/10/08)
			bb.updateModel(armType, filenamei, filenamem, filenamen, sum_prior, count_prior);
			
		} else if (Operation.equalsIgnoreCase("Ratios")) {
			// add parameters to interface (added by Yang 2015/10/08)
			double sum_prior = Double.valueOf(args[2]);
			int count_prior = Integer.valueOf(args[3]);
			// add parameters to interface (modified by Yang 2015/10/08)
			String filenamem = args[4];
			
			File file = new File(filenamem);
			if (!file.exists()) {
				System.out.println("[Error] File " + filenamem + " not exist!");
				help();
				return;
			}
			
			BanditContextualBatch bb = new BanditContextualBatch();
			// add parameters to interface (modified by Yang 2015/10/08)
			HashMap<String, HashMap<String, Double>> ratios = bb.outputRatios(armType, filenamem, sum_prior, count_prior);
			System.out.println(ratios);
			
		} else if (Operation.equalsIgnoreCase("RatiosNewArms")) {
			// add parameters to interface (modified by Yang 2015/10/08)
			if (args.length<7) {
				System.out.println("[Error] Parameter not enough!");
				help();
				return;
			}
			
			// add parameters to interface (added by Yang 2015/10/08)
			double sum_prior = Double.valueOf(args[2]);
			int count_prior = Integer.valueOf(args[3]);
			// add parameters to interface (modified by Yang 2015/10/08)
			String filenamem = args[4];
			double percentage = Double.valueOf(args[5]);
			String[] newArmNames = new String[args.length-6];
			for (int i=6; i<args.length; i++) {
				newArmNames[i-6] = args[i];
			}
			
			File file = new File(filenamem);
			if (!file.exists()) {
				System.out.println("[Error] File " + filenamem + " not exist!");
				help();
				return;
			}
			
			BanditContextualBatch bb = new BanditContextualBatch();
			// add parameters to interface (modified by Yang 2015/10/08)
			HashMap<String, HashMap<String, Double>> ratios = bb.OutputRatiosWithNewArms(armType, filenamem, percentage, newArmNames, sum_prior, count_prior);
			System.out.println(ratios);
			
		} else if (Operation.equalsIgnoreCase("RemoveArms")) {
			if (args.length<5) {
				System.out.println("[Error] Parameter not enough!");
				help();
				return;
			}
			
			String filenamem = args[2];
			String filenamen = args[3];
			String[] armNames = new String[args.length-4];
			for (int i=4; i<args.length; i++) {
				armNames[i-4] = args[i];
			}
			
			File file = new File(filenamem);
			if (!file.exists()) {
				System.out.println("[Error] File " + filenamem + " not exist!");
				help();
				return;
			}
			
			BanditContextualBatch bb = new BanditContextualBatch();
			bb.removeArms(armType, filenamem, filenamen, armNames);
		}
	}

}
